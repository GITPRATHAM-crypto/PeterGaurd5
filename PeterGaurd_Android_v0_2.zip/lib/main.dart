import 'dart:convert';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PeterGaurdApp());

class PeterGaurdApp extends StatelessWidget {
  const PeterGaurdApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PeterGaurd',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorSchemeSeed: const Color(0xFF43D9C5),
        useMaterial3: true,
      ),
      home: const DashboardPage(),
    );
  }
}

class SavedDevice {
  SavedDevice({required this.name, required this.ip});
  final String name;
  final String ip;

  Map<String, String> toJson() => {'name': name, 'ip': ip};

  factory SavedDevice.fromJson(Map<String, dynamic> json) =>
      SavedDevice(name: json['name'] as String, ip: json['ip'] as String);
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final _info = NetworkInfo();
  final _nameController = TextEditingController();
  final _ipController = TextEditingController();
  final List<SavedDevice> _devices = [];
  final Map<String, String> _deviceStatus = {};

  String _wifiIp = 'Checking…';
  String _gateway = 'Checking…';
  String _networkState = 'Checking…';
  bool _loading = true;
  final Set<String> _checking = {};

  @override
  void initState() {
    super.initState();
    _loadDevices();
    _refreshNetwork();
    Connectivity().onConnectivityChanged.listen((results) {
      if (!mounted) return;
      setState(() {
        _networkState = results.any((r) => r != ConnectivityResult.none)
            ? 'Connected'
            : 'Offline';
      });
    });
  }

  Future<void> _loadDevices() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('saved_devices') ?? '[]';
    final decoded = jsonDecode(raw) as List<dynamic>;
    if (!mounted) return;
    setState(() {
      _devices
        ..clear()
        ..addAll(decoded.map((e) =>
            SavedDevice.fromJson(Map<String, dynamic>.from(e as Map))));
    });
  }

  Future<void> _saveDevices() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'saved_devices',
      jsonEncode(_devices.map((d) => d.toJson()).toList()),
    );
  }

  Future<void> _refreshNetwork() async {
    setState(() => _loading = true);
    try {
      final ip = await _info.getWifiIP();
      final gateway = await _info.getWifiGatewayIP();
      final results = await Connectivity().checkConnectivity();
      if (!mounted) return;
      setState(() {
        _wifiIp = ip ?? 'Unavailable (connect to Wi-Fi)';
        _gateway = gateway ?? 'Unavailable';
        _networkState = results.any((r) => r != ConnectivityResult.none)
            ? 'Connected'
            : 'Offline';
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _wifiIp = 'Unavailable on this platform';
        _gateway = 'Unavailable on this platform';
        _networkState = 'Unknown';
        _loading = false;
      });
    }
  }

  bool _validIpv4(String value) {
    final parts = value.split('.');
    if (parts.length != 4) return false;
    for (final part in parts) {
      final n = int.tryParse(part);
      if (n == null || n < 0 || n > 255 || part.isEmpty) return false;
    }
    return true;
  }

  bool _isPrivateIpv4(String value) {
    if (!_validIpv4(value)) return false;
    final p = value.split('.').map(int.parse).toList();
    return p[0] == 10 ||
        (p[0] == 172 && p[1] >= 16 && p[1] <= 31) ||
        (p[0] == 192 && p[1] == 168);
  }

  Future<void> _checkDeviceHttp(SavedDevice device) async {
    // This checks one manually saved private-network device on HTTP port 80.
    // It does not scan a subnet or probe a range of ports.
    if (!_isPrivateIpv4(device.ip)) {
      setState(() => _deviceStatus[device.ip] = 'Private IP required');
      return;
    }
    if (_checking.contains(device.ip)) return;

    setState(() {
      _checking.add(device.ip);
      _deviceStatus[device.ip] = 'Checking HTTP…';
    });

    Socket? socket;
    try {
      socket = await Socket.connect(
        device.ip,
        80,
        timeout: const Duration(seconds: 2),
      );
      if (!mounted) return;
      setState(() => _deviceStatus[device.ip] = 'HTTP reachable');
    } on SocketException {
      if (!mounted) return;
      setState(() => _deviceStatus[device.ip] = 'No HTTP response');
    } on IOException {
      if (!mounted) return;
      setState(() => _deviceStatus[device.ip] = 'No HTTP response');
    } catch (_) {
      if (!mounted) return;
      setState(() => _deviceStatus[device.ip] = 'Check unavailable');
    } finally {
      socket?.destroy();
      if (mounted) setState(() => _checking.remove(device.ip));
    }
  }

  Future<void> _addDevice() async {
    final name = _nameController.text.trim();
    final ip = _ipController.text.trim();

    if (name.isEmpty || !_validIpv4(ip) || !_isPrivateIpv4(ip)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Enter a device name and a private IPv4 address (10.x, 172.16–31.x, or 192.168.x).'),
        ),
      );
      return;
    }
    if (_devices.any((d) => d.ip == ip)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('That IP address is already saved.')),
      );
      return;
    }

    setState(() => _devices.add(SavedDevice(name: name, ip: ip)));
    await _saveDevices();
    _nameController.clear();
    _ipController.clear();
    if (mounted) Navigator.pop(context);
  }

  void _showAddDialog() {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add your device'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Device name'),
            ),
            TextField(
              controller: _ipController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Private IPv4 address'),
            ),
            const SizedBox(height: 8),
            const Text(
              'Only add devices you own or have permission to monitor. The status check contacts only this saved IP on HTTP port 80.',
              style: TextStyle(fontSize: 12, color: Colors.white70),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: _addDevice, child: const Text('Save device')),
        ],
      ),
    );
  }

  Future<void> _removeDevice(int index) async {
    final ip = _devices[index].ip;
    setState(() {
      _devices.removeAt(index);
      _deviceStatus.remove(ip);
    });
    await _saveDevices();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _ipController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PeterGaurd'),
        actions: [
          IconButton(
            tooltip: 'Refresh network details',
            onPressed: _refreshNetwork,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showAddDialog,
        icon: const Icon(Icons.add),
        label: const Text('Add device'),
      ),
      body: RefreshIndicator(
        onRefresh: _refreshNetwork,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('NETWORK STATUS',
                        style: TextStyle(letterSpacing: 1.4, color: Colors.white70)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(
                          _networkState == 'Connected' ? Icons.wifi : Icons.wifi_off,
                          color: _networkState == 'Connected'
                              ? Colors.tealAccent
                              : Colors.orangeAccent,
                          size: 30,
                        ),
                        const SizedBox(width: 12),
                        Text(_loading ? 'Loading…' : _networkState,
                            style: Theme.of(context).textTheme.titleLarge),
                      ],
                    ),
                    const Divider(height: 28),
                    _detail('This device IP', _wifiIp),
                    _detail('Wi-Fi gateway', _gateway),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('MY DEVICES', style: Theme.of(context).textTheme.titleMedium),
                Text('${_devices.length} saved',
                    style: const TextStyle(color: Colors.white60)),
              ],
            ),
            const SizedBox(height: 8),
            if (_devices.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(22),
                  child: Column(
                    children: [
                      Icon(Icons.devices_other, size: 38, color: Colors.white54),
                      SizedBox(height: 8),
                      Text('No devices saved yet'),
                      SizedBox(height: 4),
                      Text(
                        'Add a device you own using its private network IP.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white60),
                      ),
                    ],
                  ),
                ),
              )
            else
              ..._devices.asMap().entries.map((entry) {
                final index = entry.key;
                final device = entry.value;
                final status = _deviceStatus[device.ip] ?? 'Not checked';
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.devices)),
                    title: Text(device.name),
                    subtitle: Text('${device.ip}\n$status'),
                    isThreeLine: true,
                    trailing: Wrap(
                      spacing: 0,
                      children: [
                        IconButton(
                          tooltip: 'Check this saved device',
                          onPressed: _checking.contains(device.ip)
                              ? null
                              : () => _checkDeviceHttp(device),
                          icon: _checking.contains(device.ip)
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.wifi_find),
                        ),
                        IconButton(
                          tooltip: 'Remove saved device',
                          icon: const Icon(Icons.delete_outline),
                          onPressed: () => _removeDevice(index),
                        ),
                      ],
                    ),
                  ),
                );
              }),
            const SizedBox(height: 90),
            const Text(
              'A successful check means the saved device accepted an HTTP connection on port 80. “No HTTP response” does not prove the device is offline; it may simply not offer HTTP. PeterGaurd does not scan IP ranges or access device contents.',
              style: TextStyle(color: Colors.white54, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _detail(String label, String value) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 125,
              child: Text(label, style: const TextStyle(color: Colors.white60)),
            ),
            Expanded(child: SelectableText(value)),
          ],
        ),
      );
}
