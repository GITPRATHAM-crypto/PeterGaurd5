# PeterGaurd Android v0.2

PeterGaurd is a defensive, personal network dashboard. This version is designed for Android first. It can later be built for Windows from the same Flutter source.

## What's new in v0.2
- Shows this tablet's Wi-Fi IP address and gateway where Android exposes them.
- Shows basic network connectivity.
- Saves a manual list of devices you own or have permission to monitor.
- Allows a one-device-at-a-time HTTP reachability check against the saved device's private IPv4 address on TCP port 80.
- Restricts saved/checkable addresses to RFC1918 private IPv4 ranges.
- No subnet sweep, port-range scan, exploit, credential collection, or remote device access.

**Important:** "HTTP reachable" means that the device accepted a connection on port 80. "No HTTP response" does not mean the device is offline; it may not run an HTTP service.

## Build an APK without owning a Windows computer

This ZIP includes a GitHub Actions workflow that builds the Android APK on a cloud runner. You need a GitHub account and internet access in the tablet browser.

1. Extract this ZIP.
2. Create a new repository on GitHub named `PeterGaurd` (a private repository is fine).
3. Upload the extracted project files and folders to the repository, keeping `.github/workflows/build-android.yml` in place. If the GitHub mobile page makes folder uploads difficult, use GitHub's browser desktop-site mode.
4. Open the repository's **Actions** tab.
5. Select **Build PeterGaurd Android APK** and choose **Run workflow** (or push/upload to the `main` branch to trigger it).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and download the artifact named `PeterGaurd-Android-APK`.
8. Extract the artifact ZIP to get `app-release.apk`, then open it on your tablet and install it. Android may ask you to allow installation from the browser or file manager you used.

The workflow builds a release APK but does not sign it with a personal release key. It is suitable for testing and installing on your own tablet; configure your own signing key before publishing to an app store.

## Local build requirements
If you later get access to a development computer, install Flutter stable and Android SDK, then run:
```bash
flutter pub get
flutter build apk --release
```

## Windows later
When you have access to a Windows computer with Flutter and Visual Studio's Desktop development with C++ workload:
```bash
flutter create --platforms=windows .
flutter build windows --release
```

## Dependencies
- Flutter
- connectivity_plus
- network_info_plus
- shared_preferences
